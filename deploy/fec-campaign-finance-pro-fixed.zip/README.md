# FEC Campaign Finance Pro

Campaign money from the FEC's own OpenFEC API, in clean rows: candidate search, committee search, itemized individual contributions (Schedule A) and independent expenditures (Schedule E).

**Pricing: $0.005 per run + $2.00 per 1,000 result rows.** No proxies, no scrapers: every row comes from the FEC's official JSON API, so the rows are exactly what the FEC published.

## Comparison

| | [fec-campaign-finance-pro](https://apify.com/red.cars/fec-campaign-finance-pro) (this actor) | [ryanclinton/fec-campaign-finance](https://apify.com/ryanclinton/fec-campaign-finance) (category leader) |
|---|---|---|
| Price | $0.005/run + $2.00 per 1,000 rows | $0.002 per record + $0.00005/GB start |
| Search types | 4 in one actor: candidates, committees, contributions (Schedule A), expenditures (Schedule E) | contributions focus |
| API key | Your own free FEC key supported; shared DEMO_KEY fallback | fixed |
| Result cap | Hard maxItems cap, run stops at the cap | config-dependent |
| Rows | Flattened, typed rows with links to the FEC record and filing PDF | nested/mixed |

The leader sits at 3 active users in the last 30 days with no public reviews; this actor ships the same per-row price with all four FEC search surfaces in one call.

## Input

| Field | Type | Default | What it does |
|---|---|---|---|
| `searchType` | select | `candidates` | `candidates`, `committees`, `contributions`, `expenditures` |
| `query` | string | empty | Name to search: candidate/committee name (q), contributor name (Schedule A), payee name (Schedule E) |
| `committeeId` | string | empty | FEC committee ID, e.g. `C00401224`. Use it for money queries to stay fast |
| `candidateId` | string | empty | FEC candidate ID for expenditure pulls, e.g. `H6TX34072` |
| `office` | select | any | `H` House, `S` Senate, `P` President (candidate search) |
| `state` | string | empty | Two-letter state, e.g. `TX` |
| `party` | string | empty | `DEM`, `REP`, ... |
| `twoYearPeriod` | number | `2026` | FEC two-year transaction period for money queries |
| `dateFrom` / `dateTo` | string | empty | Date window `YYYY-MM-DD` for contributions/expenditures |
| `minAmount` | number | `0` | Minimum contribution amount |
| `maxItems` | number | `10` | Hard cap on rows; the run stops at the cap so you never pay for rows you didn't ask for |
| `apiKey` | string | empty | OpenFEC API key. Empty uses the shared `DEMO_KEY`, which is rate limited |

## Output

Each dataset item is one flat row with a `searchType` marker.

- **candidates**: `candidateId`, `name`, `party`, `office`, `state`, `district`, `lastCycle`, `hasRaisedFunds`, `incumbentStatus`, `firstFiled`, `lastFiled`, `committeeIds`, `fecLink`
- **committees**: `committeeId`, `name`, `designation`, `type`, `state`, `party`, `treasurer`, `lastCycle`, `firstFiled`, `linkedCandidates`, `fecLink`
- **contributions**: `contributor`, `employer`, `occupation`, `city`, `state`, `amount`, `receiptDate`, `aggregateYtd`, `committeeId`, `committeeName`, `candidateName`, `pdfUrl`
- **expenditures**: `payee`, `amount`, `expenditureDate`, `description`, `committeeId`, `committeeName`, `candidateName`, `candidateId`, `supportOrOppose`, `filingNumber`, `pdfUrl`

A run that matches nothing pushes a single `ZERO_RESULTS` hint row (the only billed item) so you can see why.

## Use cases

- Journalists and researchers tracking who funds which campaigns this cycle
- Compliance and PAC teams screening donors before outreach
- Opposition research: full contribution trails by committee, employer or window
- Ad intelligence: who is spending money on independent expenditures for or against a candidate

## FAQ

**Do I need an API key?** No. Empty uses the FEC's shared `DEMO_KEY`, which is heavily rate limited. For reliable volume get a free key in one minute at [api.data.gov/signup](https://api.data.gov/signup/) and paste it into `apiKey`.

**Why do money queries need a filter?** Unfiltered Schedule A pulls span millions of rows and time out on the FEC's side. Give it a `committeeId`, a contributor `query`, or a `candidateId` (and ideally a date window).

**Which cycle do I get?** Money queries default to `twoYearPeriod: 2026`. Set `2024`, `2022`, ... for historical cycles.

**Can I pull more than 10 rows?** Yes: raise `maxItems` (cap 5,000 per run). The run stops exactly at the cap.

**Is the data official?** Yes, every field comes from the FEC's public OpenFEC API (api.open.fec.gov). Rows link back to fec.gov records and filing PDFs.

## Pair it with

**[Congress Stock Trades Pro](https://apify.com/red.cars/congress-stock-trades-pro)** covers the trading side of the same money: House member PTR filings parsed into rows with amount midpoints and links to the source PDF, $0.005 per run + $1.50 per 1,000 rows.
